package mid;

import java.util.Scanner;

public class main {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		
		ITdepartment itobjectArray[]= new ITdepartment[5];
		
		HRdepartment hrobjectArray[]= new HRdepartment[5];
		
		
		ITdepartment ITobj = new ITdepartment();
		HRdepartment HRobj = new HRdepartment();
	
		
		for(int i=0;i<itobjectArray.length;i++)
		{
			System.out.println("Enter Employee name: ");
			itobjectArray[i].setEmpName(scan.nextLine());
			System.out.println("Enter location : ");
			itobjectArray[i].setLoaction(scan.nextLine());
			System.out.println("Enter Total exp: ");
			itobjectArray[i].setTotalExperience(scan.nextInt());
			
			System.out.println("Enter agep: ");
			itobjectArray[i].setAge(scan.nextInt());
			
			System.out.println("Enter empid: ");
			itobjectArray[i].setEmpid(scan.nextInt());
			
			System.out.println("Enter salary: ");
			itobjectArray[i].setSalary(scan.nextInt());
			
			
			
		}
		for(int i=0;i<hrobjectArray.length;i++)
		{
			System.out.println("Enter adreess: ");
			hrobjectArray[i].setAddress(scan.nextLine());
			
				System.out.println("Enter degination: ");
				hrobjectArray[i].setDesignation(scan.nextLine());
			
			
		}
		
		
		for(int i=0;i<hrobjectArray.length;i++)
		{
			System.out.println(hrobjectArray[i].toString());
		}
		
		for(int i=0;i<itobjectArray.length;i++)
		{
			System.out.println(itobjectArray[i].toString());
		}
		
		System.out.println("Average age : "+ITobj.averageAge(itobjectArray));
		
		System.out.println("Highest salsayr of IT department: ");
		System.out.println(ITobj.highestSalary(itobjectArray));
		
		
		HRobj.minSalary(hrobjectArray,itobjectArray);
		
		
		
		
		
	}

}
