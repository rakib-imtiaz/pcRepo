import java.io.IOException;

import javax.swing.JFrame;

public class main {

	public static void main(String[] args) throws IOException {

		homepage f = new homepage();
		f.setVisible(true);
	
	}

}

