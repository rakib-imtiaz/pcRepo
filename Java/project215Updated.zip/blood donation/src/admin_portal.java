import java.awt.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class admin_portal extends JFrame implements ActionListener {

	JFrame frame;
	JButton Adddonorbtn, Displaydonorbtn, logoutbtn,updatebtn;

	public admin_portal() {
		getContentPane().setBackground(SystemColor.control);
		setBackground(new Color(255, 255, 255));
		setResizable(false);

		this.frame = new JFrame();
		this.setTitle("Admin Portal");
		this.setBounds(40, 40, 309, 364);
		getContentPane().setLayout(null);

		JButton btnNewButton = new JButton("Add Donor");
		btnNewButton.setBackground(new Color(47, 79, 79));
		btnNewButton.setForeground(new Color(255, 255, 255));
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnNewButton.setBounds(80, 41, 153, 25);
		getContentPane().add(btnNewButton);

		JButton deletebtn = new JButton("Delete Donor");
		deletebtn.setBackground(new Color(47, 79, 79));
		deletebtn.setForeground(new Color(255, 255, 255));
		deletebtn.setBounds(80, 105, 153, 25);
		getContentPane().add(deletebtn);

		JButton viewbtn = new JButton("View All Donor");
		viewbtn.setBackground(new Color(47, 79, 79));
		viewbtn.setForeground(new Color(255, 255, 255));
		viewbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		viewbtn.setBounds(80, 167, 153, 25);
		getContentPane().add(viewbtn);

		  updatebtn = new JButton("Update Donor");
		updatebtn.setBackground(new Color(47, 79, 79));
		updatebtn.setForeground(new Color(255, 255, 255));
		updatebtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		updatebtn.setBounds(80, 228, 153, 25);
		getContentPane().add(updatebtn);

		 logoutbtn = new JButton("Log Out");
		logoutbtn.setBackground(new Color(0, 0, 255));
		logoutbtn.setForeground(new Color(255, 255, 255));
		logoutbtn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		logoutbtn.setBounds(108, 278, 104, 44);
		getContentPane().add(logoutbtn);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		// this.pack();

	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==Adddonorbtn)
		{
			dispose();
			
			
		}
		
		if(e.getSource()==logoutbtn)
		{
			dispose();
			admin_portal p = new admin_portal();
			p.setVisible(true);
			
			
		}
		
		// TODO Auto-generated method stub

	}
}
