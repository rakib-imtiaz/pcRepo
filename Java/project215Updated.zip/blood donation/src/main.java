import java.io.IOException;

import javax.swing.JFrame;

public class main {

	public static void main(String[] args) throws IOException {

		homepage f = new homepage();
		//donor_profile f = new donor_profile();
		//donor_profile f = new donor_profile();
		f.setVisible(true);

	}

}
