package Def;
import java.io.IOException;
import java.util.Scanner;

import admin.Administrator;
import customer.customerManagement;

public class Driver {
	
	public static void main(String[] args) throws IOException {
		
		portal p = new portal();
				
	}
	
	

}
