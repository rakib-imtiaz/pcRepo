
      function changeText(){
        var massage = document.getElementById('massage');
        heading.innerHTML = 'drug fair';
      }
