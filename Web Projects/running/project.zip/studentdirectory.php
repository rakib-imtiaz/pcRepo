<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Document</title>
</head>
<body>
     <table border="1px"; width="250px" height="250">
        <tr>
            <td> view documents</td>
        </tr>
        <tr>
            <td> Delete documents</td>
        </tr>
        <tr>
            <td> <a href="homepage.php"></a>Home</td>
        </tr>
     
     </table>
     
    
    
    
    
</body>
</html>